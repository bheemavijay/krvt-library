import { LibraryClient } from "@/components/library-client";
import { getNovels } from "@/lib/db";

export default async function HomePage() {
  const novels = await getNovels();

  return <LibraryClient novels={novels} />;
}
