import { ReaderPageClient } from "@/components/reader/reader-page-client";
import { getNovelById } from "@/lib/db";

type ChapterPageProps = {
  params: Promise<{
    id: string;
    chapter: string;
  }>;
};

export default async function ChapterPage({ params }: ChapterPageProps) {
  const { id, chapter } = await params;
  const chapterNumber = Number.parseInt(chapter, 10);
  const novel = Number.isInteger(chapterNumber)
    ? await getNovelById(id, { mode: "full", chapterNumber })
    : await getNovelById(id, { mode: "list" });

  return (
    <ReaderPageClient
      initialNovel={novel}
      novelId={id}
      chapterParam={chapter}
    />
  );
}
