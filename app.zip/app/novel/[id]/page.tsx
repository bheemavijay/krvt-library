"use client";

import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import Link from "next/link";

import { getNovelById } from "@/lib/storage/library";

export default function ReaderPage() {
  const params = useParams();

  const novelId = params?.id as string;
  const chapterParam = params?.chapter as string;

  const [novel, setNovel] = useState<any>(null);

  useEffect(() => {
    if (!novelId) return;

    const data = getNovelById(novelId);
    setNovel(data);
  }, [novelId]);

  // loading state
  if (!novel) {
    return <p className="p-6">Loading...</p>;
  }

  // safe chapter index
  let chapterIndex = Number(chapterParam) - 1;

  if (isNaN(chapterIndex) || chapterIndex < 0) {
    chapterIndex = 0;
  }

  if (chapterIndex >= novel.chapters.length) {
    chapterIndex = novel.chapters.length - 1;
  }

  const chapter = novel.chapters[chapterIndex];

  // fallback if no chapters
  if (!chapter) {
    return (
      <div className="p-6 space-y-2">
        <p className="text-red-400">Chapter not found ❌</p>
        <p>Index: {chapterIndex}</p>
        <p>Total chapters: {novel.chapters.length}</p>
      </div>
    );
  }

  return (
    <main className="max-w-3xl mx-auto p-6 space-y-6">

      {/* Back */}
      <Link href={`/novel/${novel.id}`} className="text-sm text-blue-400">
        ← Back to Novel
      </Link>

      {/* Title */}
      <h1 className="text-2xl font-bold">
        Chapter {chapterIndex + 1}: {chapter.title}
      </h1>

      {/* Content */}
      <div className="space-y-4 leading-7 text-gray-200">
        {chapter.content
          ?.split("\n")
          .filter((line: string) => line.trim() !== "")
          .map((line: string, i: number) => (
            <p key={i}>{line}</p>
          ))}
      </div>

      {/* Navigation */}
      <div className="flex justify-between mt-10">

        {/* Previous */}
        {chapterIndex > 0 ? (
          <Link
            href={`/novel/${novel.id}/${chapterIndex}`}
            className="text-blue-400"
          >
            ← Previous
          </Link>
        ) : (
          <div />
        )}

        {/* Next */}
        {chapterIndex < novel.chapters.length - 1 ? (
          <Link
            href={`/novel/${novel.id}/${chapterIndex + 2}`}
            className="text-blue-400"
          >
            Next →
          </Link>
        ) : (
          <div />
        )}

      </div>

    </main>
  );
}