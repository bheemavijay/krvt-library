import { NextResponse } from "next/server";
import * as cheerio from "cheerio";

// ✅ fetch with browser headers
async function fetchPage(url: string) {
  return fetch(url, {
    headers: {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36",
      "Accept-Language": "en-US,en;q=0.9",
    },
  });
}

export async function POST(req: Request) {
  try {
    const { url } = await req.json();

    if (!url) {
      return NextResponse.json({ error: "URL required" }, { status: 400 });
    }

    const baseUrl = new URL(url).origin;

    // ✅ fetch main page
    const res = await fetchPage(url);
    const html = await res.text();
    const $ = cheerio.load(html);

    const title =
      $("h3.title").text().trim() ||
      $("h1").first().text().trim() ||
      "Unknown Title";

    let chapterLinks: string[] = [];

    // ✅ pagination loop (novelfull style)
    for (let page = 1; page <= 10; page++) {
      const pageUrl = `${url}?page=${page}&per-page=50`;

      const pageRes = await fetchPage(pageUrl);
      const pageHtml = await pageRes.text();

      const $$ = cheerio.load(pageHtml);

      const found: string[] = [];

      $$(".list-chapter a").each((_, el) => {
        const link = $$(el).attr("href");

        if (link) {
          const fullLink = link.startsWith("http")
            ? link
            : baseUrl + link;

          chapterLinks.push(fullLink);
          found.push(fullLink);
        }
      });

      console.log(`Page ${page}: ${found.length}`);

      // stop if page empty
      if (found.length === 0) break;
    }

    // remove duplicates
    chapterLinks = [...new Set(chapterLinks)];

    console.log("TOTAL CHAPTERS:", chapterLinks.length);

    if (chapterLinks.length === 0) {
      return NextResponse.json(
        { error: "No chapters found (pagination failed)" },
        { status: 500 }
      );
    }

    // ✅ limit for testing (change later)
    const limitedLinks = chapterLinks.slice(0, 5);

    const chapters = [];

    for (let i = 0; i < limitedLinks.length; i++) {
      console.log(`Fetching chapter ${i + 1}`);

      const chRes = await fetchPage(limitedLinks[i]);
      const chHtml = await chRes.text();

      const $$ = cheerio.load(chHtml);

      const chTitle =
        $$(".chr-title").text().trim() ||
        $$("h3").first().text().trim() ||
        `Chapter ${i + 1}`;

      const content = $$("#chr-content")
        .text()
        .replace(/\s+/g, " ")
        .trim();

      chapters.push({
        id: String(i + 1),
        title: chTitle,
        content,
      });
    }

    return NextResponse.json({
      title,
      chapters,
    });

  } catch (err) {
    console.error(err);

    return NextResponse.json(
      { error: "Scraping failed" },
      { status: 500 }
    );
  }
}