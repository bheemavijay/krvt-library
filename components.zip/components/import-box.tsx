"use client";

import { useState } from "react";
import { addNovel } from "@/lib/storage/library";
import { PasteImportForm } from "./paste-import-form";
import { UploadNovelForm } from "./upload-novel-form";
import { Button } from "@/components/ui/button";

export function ImportBox() {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);

  const handleImport = async () => {
    if (!url.trim()) return alert("Enter URL");

    setLoading(true);

    try {
      const res = await fetch("/api/import", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ url }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Failed");
      }

      addNovel({
        id: Math.random().toString(36),
        title: data.title,
        chapters: data.chapters,
        createdAt: Date.now(),
      });

      alert("✅ Imported!");
      window.location.reload();

    } catch (err: any) {
      alert(err.message || "Error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">

      {/* 🔥 URL IMPORT */}
      <div className="space-y-3 border p-4 rounded">
        <h2 className="text-lg font-semibold">Import from URL</h2>

        <input
          type="text"
          placeholder="https://novelfull.com/..."
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className="w-full border p-2 rounded"
        />

        <Button onClick={handleImport}>
          {loading ? "Importing..." : "Import"}
        </Button>
      </div>

      {/* 🔥 OTHER METHODS */}
      <div className="grid gap-6 xl:grid-cols-2">
        <PasteImportForm />
        <UploadNovelForm />
      </div>

    </div>
  );
}