"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

import { getNovelById } from "@/lib/storage/library";
import { Button } from "@/components/ui/button";

type Props = {
  novelId: string;
};

export function NovelPageClient({ novelId }: Props) {
  const [novel, setNovel] = useState<any>(null);

  useEffect(() => {
    const data = getNovelById(novelId);
    setNovel(data);
  }, [novelId]);

  if (!novel) {
    return (
      <main className="flex min-h-[60vh] items-center justify-center">
        <p>Novel not found ❌</p>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-4xl p-6 space-y-6">

      <Link href="/">← Back</Link>

      <h1 className="text-3xl font-bold">{novel.title}</h1>

      <p className="text-sm text-gray-400">
        {novel.chapters.length} chapters
      </p>

      <div className="space-y-3">
        {novel.chapters.map((ch: any, i: number) => (
          <Link
            key={ch.id}
            href={`/novel/${novel.id}/${i + 1}`}
            className="block border p-3 rounded hover:bg-gray-800"
          >
            Chapter {i + 1}: {ch.title}
          </Link>
        ))}
      </div>

      {novel.chapters.length > 0 && (
        <Button href={`/novel/${novel.id}/1`}>
          Start Reading
        </Button>
      )}

    </main>
  );
}