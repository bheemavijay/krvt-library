"use client";

import { useEffect, useMemo, useState, useSyncExternalStore } from "react";

import type { Novel } from "@/types";

import { ReaderShell } from "@/components/reader/reader-shell";
import { Button } from "@/components/ui/button";
import {
  getServerUploadedLibraryState,
  getUploadedLibraryState,
  subscribeToUploadedLibrary,
} from "@/lib/library-storage";
import {
  getChapters as getLocalChapters,
  getNovelById as getLocalNovelById,
} from "@/lib/library-api";

type ReaderPageClientProps = {
  initialNovel: Novel | null;
  novelId: string;
  chapterParam: string;
};

export function ReaderPageClient({
  initialNovel,
  novelId,
  chapterParam,
}: ReaderPageClientProps) {
  const uploadedLibrary = useSyncExternalStore(
    subscribeToUploadedLibrary,
    getUploadedLibraryState,
    getServerUploadedLibraryState,
  );

  const uploadedNovel =
    uploadedLibrary.novels.find((entry) => entry.novel.id === novelId)?.novel ?? null;
  const [apiNovel, setApiNovel] = useState<Novel | null>(null);
  const [isLoadingApiNovel, setIsLoadingApiNovel] = useState(
    !initialNovel && !uploadedNovel,
  );
  const [apiError, setApiError] = useState<string | null>(null);

  useEffect(() => {
    if (initialNovel || uploadedNovel) {
      setIsLoadingApiNovel(false);
      return;
    }

    let isActive = true;

    async function loadApiNovel() {
      setIsLoadingApiNovel(true);
      setApiError(null);

      try {
        const requestedChapterNumber = Number.parseInt(chapterParam, 10);
        const [novelSummary, chapters] = await Promise.all([
          getLocalNovelById(novelId),
          getLocalChapters(novelId, {
            mode: "full",
            chapterNumber: Number.isInteger(requestedChapterNumber)
              ? requestedChapterNumber
              : undefined,
          }),
        ]);

        if (!isActive) {
          return;
        }

        if (!novelSummary || chapters.length === 0) {
          setApiNovel(null);
          return;
        }

        setApiNovel({
          id: novelSummary.id,
          title: novelSummary.title,
          author: novelSummary.author,
          chapters,
        });
      } catch (error) {
        if (!isActive) {
          return;
        }

        setApiError(
          error instanceof Error
            ? `The local library API could not load this novel. Showing fallback data if available. ${error.message}`
            : "The local library API could not load this novel. Showing fallback data if available.",
        );
        setApiNovel(null);
      } finally {
        if (isActive) {
          setIsLoadingApiNovel(false);
        }
      }
    }

    void loadApiNovel();

    return () => {
      isActive = false;
    };
  }, [chapterParam, initialNovel, novelId, uploadedNovel]);

  const novel = useMemo(
    () => initialNovel ?? uploadedNovel ?? apiNovel,
    [apiNovel, initialNovel, uploadedNovel],
  );
  const chapterNumber = Number(chapterParam);
  const chapterIndex = Number.isInteger(chapterNumber) ? chapterNumber - 1 : -1;

  if (isLoadingApiNovel && !novel) {
    return (
      <main className="flex min-h-[60vh] flex-col items-center justify-center gap-4 text-center">
        <span className="size-8 animate-spin rounded-full border-2 border-accent/30 border-t-accent" />
        <p className="text-sm text-muted">Loading novel from your local library...</p>
      </main>
    );
  }

  if (!novel) {
    return (
      <main className="flex min-h-[60vh] flex-col items-center justify-center gap-4 text-center">
        <p className="text-sm uppercase tracking-[0.3em] text-muted">Missing story</p>
        <h1 className="font-heading text-3xl text-foreground">
          This novel is not available in your library.
        </h1>
        <p className="max-w-md text-sm leading-7 text-muted">
          It may have been removed from local storage or the link is invalid.
        </p>
        {apiError ? (
          <p className="max-w-xl rounded-xl border border-amber-400/20 bg-amber-400/10 px-4 py-3 text-sm text-amber-100">
            {apiError}
          </p>
        ) : null}
        <Button href="/">Return to library</Button>
      </main>
    );
  }

  if (chapterIndex < 0 || chapterIndex >= novel.chapters.length) {
    return (
      <main className="flex min-h-[60vh] flex-col items-center justify-center gap-4 text-center">
        <p className="text-sm uppercase tracking-[0.3em] text-muted">Missing chapter</p>
        <h1 className="font-heading text-3xl text-foreground">
          This chapter is not available.
        </h1>
        <p className="max-w-md text-sm leading-7 text-muted">
          Choose another chapter from the novel details page.
        </p>
        <Button href={`/novel/${novel.id}`}>Back to novel</Button>
      </main>
    );
  }

  return (
    <>
      {apiError ? (
        <p className="mx-auto mb-4 w-full max-w-5xl rounded-[1.25rem] border border-amber-400/20 bg-amber-400/10 px-4 py-3 text-sm text-amber-100">
          {apiError}
        </p>
      ) : null}
      <ReaderShell novel={novel} chapterIndex={chapterIndex} />
    </>
  );
}
