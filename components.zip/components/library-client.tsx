"use client";

import { useEffect, useState } from "react";
import { getLibrary, Novel } from "@/lib/storage/library";
import { NovelGrid } from "@/components/novel-grid";

export function LibraryClient() {
  const [novels, setNovels] = useState<Novel[]>([]);

  useEffect(() => {
    const data = getLibrary();
    setNovels(data);
  }, []);

  if (!novels.length) {
    return <p className="text-center mt-10">No novels yet 📚</p>;
  }

  return <NovelGrid novels={novels} />;
}