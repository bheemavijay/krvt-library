import { addNovel } from "./storage/library";

function generateId() {
  return Math.random().toString(36).substring(2, 10);
}

export function importFromText(text: string, title: string) {
  if (!text || !title) {
    throw new Error("Missing title or content");
  }

  const chapters = parseChapters(text);

  const novel = {
    id: generateId(),
    title,
    chapters,
    createdAt: Date.now(),
  };

  addNovel(novel);

  return novel;
}

function parseChapters(text: string) {
  const lines = text.split("\n");

  const chapters = [];
  let current = {
    id: generateId(),
    title: "Chapter 1",
    content: "",
  };

  let chapterCount = 1;

  for (const line of lines) {
    if (line.toLowerCase().includes("chapter")) {
      chapters.push(current);

      chapterCount++;
      current = {
        id: generateId(),
        title: line.trim() || `Chapter ${chapterCount}`,
        content: "",
      };
    } else {
      current.content += line + "\n";
    }
  }

  chapters.push(current);

  return chapters;
}