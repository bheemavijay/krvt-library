export interface Chapter {
  id: string;
  title: string;
  content: string;
}

export interface Novel {
  id: string;
  title: string;
  author?: string;
  cover?: string;
  chapters: Chapter[];
  createdAt: number;
}

const STORAGE_KEY = "krvt_library";

export function getLibrary(): Novel[] {
  if (typeof window === "undefined") return [];

  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
}

export function saveLibrary(novels: Novel[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(novels));
}

export function addNovel(newNovel: Novel) {
  const novels = getLibrary();

  // ❗ prevent duplicate titles
  const exists = novels.some(
    (n) => n.title.toLowerCase() === newNovel.title.toLowerCase()
  );

  if (exists) {
    throw new Error("Novel already exists");
  }

  novels.unshift(newNovel);
  saveLibrary(novels);
}

export function getNovelById(id: string): Novel | undefined {
  return getLibrary().find((n) => n.id === id);
}